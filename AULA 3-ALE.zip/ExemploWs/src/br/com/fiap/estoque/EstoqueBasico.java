package br.com.fiap.estoque;

public class EstoqueBasico {

	public int soma(int nr1, int nr2) {
		return (nr1 + nr2);
	}
	public int subtracao(int nr1, int nr2) {
		return (nr1 - nr2);
	}
	public int divisao(int nr1, int nr2) {
		return (nr1 / nr2);
	}
	public int multiplicacao(int nr1, int nr2) {
		return (nr1 * nr2);
	}
	
	
	
}
